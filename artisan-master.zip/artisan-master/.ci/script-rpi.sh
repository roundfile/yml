#!/bin/sh

set -ex
src/build-rpi2-qemu.sh

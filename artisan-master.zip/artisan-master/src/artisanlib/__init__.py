__version__ = '2.6.1' #
__revision__ = '0'
__build__ = '0'

__release_sponsor_name__ = 'Showroom Coffee'
__release_sponsor_domain__ = 'showroomcoffee.com'
__release_sponsor_url__ = 'https://showroomcoffee.com/'
